# Frogger (2D)

> Frogger is an action game developed by Konami and manufactured by Sega as an arcade game in 1981. The player directs each frog to its home by crossing a busy road and navigating a hazardous river, scoring points along the way.

- **Difficulty**: Intermediate
- **Topics**: Sprites, Collision, Coroutines
- **Version**: Unity 2019.4 LTS
- [**Download**](https://github.com/zigurous/unity-frogger-tutorial/archive/refs/heads/main.zip)
- [**Watch Video**](https://youtu.be/GxlxZ5q__Tc)
